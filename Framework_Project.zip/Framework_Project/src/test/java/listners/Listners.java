package listners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import resourse.Base;
import utility.Extent_Report;

import java.io.IOException;

public class Listners extends Base implements ITestListener  {

    WebDriver driver =null;
    ExtentTest testreport;
    ExtentReports extent_report = Extent_Report.getExtentReport();




    @Override
    public void onFinish(ITestContext arg0) {

        extent_report.flush();




    }

    @Override
    public void onStart(ITestContext arg0) {







    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {

    }

    @Override
    public void onTestFailure(ITestResult arg0) {



        String testname = arg0.getName();

        testreport.fail(arg0.getThrowable());

        try {
            driver = (WebDriver)arg0.getTestClass().getRealClass().getDeclaredField("driver").get(arg0.getInstance());
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {

        }


        try {
            takescreenshot(testname,driver);
        } catch (Exception e) {

        }

    }





    @Override
    public void onTestSkipped(ITestResult arg0) {


    }

    @Override
    public void onTestStart(ITestResult arg0) {
        String testname = arg0.getName();
        testreport = extent_report.createTest(testname + "Test Started Successfully");

    }

    @Override
    public void onTestSuccess(ITestResult arg0) {

        String testname = arg0.getName();

        testreport.log(Status.PASS,testname+"Test got pass");





    }
}