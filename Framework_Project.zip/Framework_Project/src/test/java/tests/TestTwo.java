package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.v85.backgroundservice.BackgroundService;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;


import pageobjects.Pageoject;
import resourse.Base;

import java.io.IOException;
import java.time.Duration;

public class TestTwo extends Base {

    public WebDriver driver;
   public JavascriptExecutor js;

    @Test
    public void testcase01() throws IOException, InterruptedException {

        driver=invokebrowser();

        Pageoject po = new Pageoject(driver);
        po.insertamount("5");
        po.insertfromvalue("USD");
        po.inserttovalue("INR");

        js.executeScript("document.querySelector('yld-tag-host-campaign')._root.querySelector('element-JcZ3Ek').click();");

        Thread.sleep(3000);

        String result = driver.findElement(By.cssSelector(".result__BigRate-sc-1bsijpp-1.iGrAod")).getText();
        System.out.println(result);



    }

    @AfterMethod
    public void teardown(){

        driver.close();
    }

}
