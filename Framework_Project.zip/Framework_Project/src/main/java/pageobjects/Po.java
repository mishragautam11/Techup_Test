package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class Po {

    By amount = By.xpath("//div[@class='text-input__TextInput-sc-17mujrb-0 amount-input__Wrapper-sc-1gq6pic-0 jApTut ezbfAz']");

    WebDriver driver ;

    public Po(WebDriver driver){

        this.driver=driver;
    }

    public WebElement clickbtn(){
        driver.findElement(amount).click();


        return null;
    }
}
