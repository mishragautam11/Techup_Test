package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class Pageoject {


    By amountfield = By.id("amount");
    By fromfield = By.id("midmarketFromCurrency");
    By tofield =   By.id("midmarketToCurrency");
    By convertbtn = By.xpath("//button[text()=\"Convert\"]");


    public WebDriver driver;

    public Pageoject(WebDriver driver){

        this.driver= driver;
    }



    public void insertamount(String num){
        driver.findElement(amountfield).sendKeys(num);

    }

    public void  insertfromvalue(String from){
        driver.findElement(fromfield).sendKeys(from,Keys.ENTER);

    }
    public void inserttovalue(String to){

        driver.findElement(tofield).sendKeys(to,Keys.ENTER);
        driver.findElement(convertbtn).click();

    }

}
