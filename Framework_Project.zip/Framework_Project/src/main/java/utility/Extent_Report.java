package utility;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import resourse.Base;


public class Extent_Report extends Base {

    static ExtentReports extentReport;

    public static  ExtentReports getExtentReport() {

        String extentReportPath = System.getProperty("user.dir")+"\\reports\\extentreport.html";
        ExtentSparkReporter reporter = new ExtentSparkReporter(extentReportPath);
        reporter.config().setReportName("Gautam Automation Results");
        reporter.config().setDocumentTitle("Test Results");

        extentReport = new ExtentReports();
        extentReport.attachReporter(reporter);
        extentReport.setSystemInfo("Operating System","Windows 10");
        extentReport.setSystemInfo("Tested By","Gautam");

        return extentReport;

    }
}
