package resourse;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

public class Base {

   public WebDriver driver ;
   public Properties prop;



    public WebDriver invokebrowser() throws IOException {

         prop = new Properties();

        String propfile = System.getProperty("user.dir")+"\\src\\main\\java\\resourse\\data.properties";
        FileInputStream fis = new FileInputStream(propfile);
        prop.load(fis);

        String browser = prop.getProperty("browsername");

        if (browser.equalsIgnoreCase("chrome")){

            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
        } else if (browser.equalsIgnoreCase("firefox")) {

            WebDriverManager.firefoxdriver().setup();
            driver = new FirefoxDriver();

        }

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        driver.get(prop.getProperty("url"));

            return driver;
    }

    public void takescreenshot(String testname, WebDriver driver) throws IOException {

        File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

        String ssdestination = System.getProperty("user.dir") + "\\screenshots\\"+testname+".png";
        FileUtils.copyFile(src,new File(ssdestination));

    }
}
